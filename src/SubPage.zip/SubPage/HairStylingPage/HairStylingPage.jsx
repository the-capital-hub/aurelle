
import { Link } from "react-router-dom";
import {
  Scissors,
  UserRound,
  Sparkles,
  Brush,
  Droplets,
  Flower2,
  Hand,
  Layers,
  Heart,
  ShieldCheck,
  Star,
  CalendarDays,
  ArrowRight,
  Gem,
  Wind,
} from "lucide-react";

import "./HairStylingPage.css";

const serviceCategories = [
  { name: "Hair & Styling", slug: "hair", icon: Scissors },
  { name: "Men's Grooming", slug: "grooming", icon: UserRound },
  { name: "Skin & Facial Care", slug: "skin", icon: Sparkles },
  { name: "Makeup & Bridal", slug: "makeup", icon: Brush },
  { name: "Nail Studio", slug: "nails", icon: Gem },
  { name: "Waxing & Threading", slug: "waxing", icon: Layers },
  { name: "Manicure & Pedicure", slug: "pedicure", icon: Hand },
  { name: "Body & Spa", slug: "body-spa", icon: Flower2 },
  { name: "Bridal & Groom Packages", slug: "packages", icon: Heart },
];

const hairServices = [
  {
    number: "01",
    title: "Hair Cut & Style",
    description:
      "Professional hair cutting and styling services for a fresh, polished and well groomed look.",
    services: [
      "Hair Cut",
      "Kids Hair Cut",
      "Beard Trim",
      "Beard Design",
      "Shaving",
      "Hair Wash & Setting",
    ],
    image: "/images/services/hair/aurelle-gallery-hair.jpg",
    alt: "Professional haircut and styling",
    icon: Scissors,
  },
  {
    number: "02",
    title: "Hair Rebonding",
    description:
      "Professional hair smoothening and restructuring treatments for a sleek and manageable finish.",
    services: [
      "Straightening",
      "Permanent Blowdry",
      "Keratin",
      "Nanoplastia",
      "Botox",
    ],
    image: "/images/services/hair/aurelle-service-hair.jpg",
    alt: "Professional hair rebonding treatment",
    icon: Wind,
  },
  {
    number: "03",
    title: "Hair Colouring",
    description:
      "Professional hair colouring services to create beautiful colour effects and personalised looks.",
    services: [
      "Per Streak",
      "Global Colour",
      "Global Colour Without Ammonia",
      "Highlights",
      "Beard Colouring",
    ],
    image: "/images/services/hair/aurelle-gallery-haircolour.jpg",
    alt: "Professional hair colouring",
    icon: Brush,
  },
  {
    number: "04",
    title: "Hair Spa",
    description:
      "Nourishing hair spa experiences and specialised scalp treatments for complete hair care.",
    services: [
      "Spa Essence",
      "Tribond Hair Spa",
      "Luxe Rejuvenation",
      "Reborn Hair Spa",
      "Royal Bliss",
      "Moroccan Oil Spa",
      "Anti Dandruff Treatments",
      "Korean Hair Spa",
    ],
    image: "/images/services/hair/aurelle-gallery-hairstyle.jpg",
    alt: "Luxury hair spa treatment",
    icon: Droplets,
  },
  {
    number: "05",
    title: "Head Massage",
    description:
      "Relaxing head massage experiences with nourishing oils and professional care.",
    services: [
      "Classic Head Massage",
      "Relaxing Head Massage",
      "Premium Hot Oil Massage",
      "Moroccan Oil Massage",
    ],
    image: "/images/services/hair/aurelle-service-hair.jpg",
    alt: "Relaxing head massage at salon",
    icon: Flower2,
  },
];

const benefits = [
  {
    icon: Star,
    title: "Expert Stylists",
    description: "Skilled professionals who understand your style.",
  },
  {
    icon: Gem,
    title: "Premium Products",
    description: "Carefully selected professional hair products.",
  },
  {
    icon: Heart,
    title: "Personalised Care",
    description: "Services tailored to your hair and preferences.",
  },
  {
    icon: ShieldCheck,
    title: "Professional Care",
    description: "A clean and comfortable salon experience.",
  },
  {
    icon: Sparkles,
    title: "Beautiful Results",
    description: "Finishing touches that complete your look.",
  },
];

export default function HairStylingPage() {
  return (
    <main className="aurelle-hair-page">

      {/* HERO SECTION */}
      <section className="hair-hero">
        <div className="hair-hero-image">
          <img
            src="/images/service-makeup/service-hair.jpg"
            alt="AURELLE luxury hair styling"
          />
        </div>

        <div className="hair-hero-overlay" />

        <div className="hair-hero-content">
          <div className="hair-breadcrumb">
            <Link to="/">Home</Link>
            <span>›</span>
            <Link to="/services">Services</Link>
            <span>›</span>
            <span>Hair & Styling</span>
          </div>

          <span className="hair-eyebrow">
            AURELLE SIGNATURE SERVICES
          </span>

          <h1>
            Hair <span>&</span> Styling
          </h1>

          <p>
            Explore professional hair cutting, rebonding,
            colouring, spa and relaxation services crafted
            around your personal style.
          </p>

          <div className="hair-hero-actions">
            <Link
              to="/booking"
              className="hair-button hair-button-light"
            >
              Book This Service <ArrowRight size={17} />
            </Link>

            <a
              href="#hair-services"
              className="hair-button hair-button-outline"
            >
              Explore Services
            </a>
          </div>
        </div>
      </section>

      {/* SERVICE CATEGORY NAVIGATION */}
      <section className="hair-category-section">
        <div className="hair-category-list">
          {serviceCategories.map((category) => {
            const Icon = category.icon;

            return (
              <Link
                key={category.slug}
                to={`/services/${category.slug}`}
                className={`hair-category-item ${
                  category.slug === "hair" ? "active" : ""
                }`}
              >
                <Icon size={27} strokeWidth={1.3} />
                <span>{category.name}</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* HAIR SERVICES */}
      <section className="hair-services-section" id="hair-services">
        <div className="hair-section-heading">
          <div>
            <span className="hair-eyebrow">OUR HAIR SERVICES</span>

            <h2>
              Complete Hair Care
              <br />
              <span>& Styling Solutions</span>
            </h2>
          </div>

          <p>
            Discover our complete range of hair services,
            from everyday styling and professional colouring
            to advanced hair treatments and relaxing massages.
          </p>
        </div>

        <div className="hair-service-grid">
          {hairServices.map((service) => {
            const Icon = service.icon;

            return (
              <article
                className="hair-service-card"
                key={service.number}
              >
                <div className="hair-service-image">
                  <img
                    src={service.image}
                    alt={service.alt}
                    loading="lazy"
                  />

                  <span className="hair-service-number">
                    {service.number}
                  </span>
                </div>

                <div className="hair-service-info">
                  <div>
                    <h3>{service.title}</h3>

                    <p>{service.description}</p>

                    <ul className="hair-service-list">
                      {service.services.map((item) => (
                        <li key={item}>
                          <Icon size={14} strokeWidth={1.5} />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Link
                    to="/pricing/hair"
                    className="hair-card-arrow"
                    aria-label={`View ${service.title} pricing`}
                  >
                    <ArrowRight size={19} />
                  </Link>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* WHY CHOOSE AURELLE */}
      <section className="hair-benefits-section">
        <div className="hair-benefits-title">
          <span className="hair-eyebrow">
            THE AURELLE EXPERIENCE
          </span>

          <h2>
            Why Choose AURELLE
            <br />
            for Hair Care?
          </h2>
        </div>

        <div className="hair-benefits-grid">
          {benefits.map((benefit) => {
            const Icon = benefit.icon;

            return (
              <div
                className="hair-benefit-item"
                key={benefit.title}
              >
                <Icon size={29} strokeWidth={1.3} />

                <h3>{benefit.title}</h3>

                <p>{benefit.description}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* HAIR CARE EXPERIENCE */}
      <section className="hair-signature-section">
        <div className="hair-signature-image">
          <img
            src="/images/services/hair/aurelle-service-hair.jpg"
            alt="AURELLE professional hair care experience"
            loading="lazy"
          />
        </div>

        <div className="hair-signature-content">
          <span className="hair-eyebrow">
            PERSONAL HAIR CARE
          </span>

          <h2>
            Your Hair
            <br />
            <span>Deserves Expert Care</span>
          </h2>

          <p>
            Explore our professional hair services and discover
            the right treatment for your individual hair needs.
            Our team is here to help you choose your experience.
          </p>

          <Link
            to="/pricing/hair"
            className="hair-button hair-button-light"
          >
            Explore Hair Pricing <ArrowRight size={17} />
          </Link>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="hair-final-cta">
        <div className="hair-cta-content">
          <div>
            <span className="hair-eyebrow">
              YOUR NEXT LOOK STARTS HERE
            </span>

            <h2>Ready for a New Look?</h2>

            <p>
              Book your Hair & Styling session at AURELLE and
              let our experts create a style that truly suits you.
            </p>
          </div>

          <Link
            to="/booking"
            className="hair-button hair-button-light"
          >
            <CalendarDays size={18} />
            Book Appointment
            <ArrowRight size={17} />
          </Link>
        </div>
      </section>

    </main>
  );
}
